from django.apps import AppConfig


class SynerdappConfig(AppConfig):
    name = 'synerdApp'
