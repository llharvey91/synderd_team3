from django import forms
from synerdApp.models import UserInfo


class HomeForm(forms.ModelForm):
    post = forms.CharField()
    fName = forms.CharField()
    lName = forms.CharField()
    address = forms.CharField()
    city = forms.CharField()
    state = forms.CharField()
    email = forms.CharField()
    cellNum = forms.CharField()

    class Meta:
        model = UserInfo
        fields = ('username', 'fName', 'lName', 'address', 'city', 'state', 'email', 'cellNum')
