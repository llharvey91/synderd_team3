from django.shortcuts import render
from django.views.generic import TemplateView

from synerdApp.forms import HomeForm
from .models import UserInfo
from django.http import HttpResponse


def index(request):
    return render(request, 'synerdApp/index.html')


class HomeView(TemplateView):
    template_name = 'synerdApp/joinUs.html'

    def joinUs(self, request):
        form = HomeForm()
        return render(request, self.template_name, {'form': form})


def logIn(request):
    return render(request, 'synerdApp/logIn.html')


def office(request):
    return render(request, 'synerdApp/office.html')


def officer(request):
    return render(request, 'synerdApp/officer.html.html')


def organization(request):
    return render(request, 'synerdApp/organization.html')


def organizationMember(request):
    return render(request, 'synerdApp/organizationMember.html')


def userinfo(request):
    return render(request, 'synerdApp/userinfo.html')


def webportal(request):
    return render(request, 'synerdApp/webportal.html')
# Create your views here.
