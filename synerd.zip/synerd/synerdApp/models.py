from django.db import models


class UserInfo(models.Model):
    username = models.CharField(max_length=50)
    fName = models.CharField(max_length=50)
    lName = models.CharField(max_length=50)
    address = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=50)
    zipCode = models.CharField(max_length=5)
    email = models.CharField(max_length=50)
    cellNum = models.CharField(max_length=10)

# Create your models here.
