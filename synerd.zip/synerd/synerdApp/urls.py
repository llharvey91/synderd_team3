from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('joinUs/', views.HomeForm, name='joinUs'),
    path('logIn/', views.logIn, name='logIn')

]